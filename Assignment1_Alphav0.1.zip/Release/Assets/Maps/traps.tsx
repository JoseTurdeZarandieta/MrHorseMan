<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="00 All" tilewidth="32" tileheight="32" spacing="2" margin="2" tilecount="1920" columns="60">
 <image source="00 All.png" width="2048" height="1088"/>
</tileset>
