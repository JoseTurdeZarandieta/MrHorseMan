<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="rino" tilewidth="64" tileheight="32" tilecount="6" columns="6">
 <image source="rino_sprites.png" width="384" height="32"/>
 <tile id="1">
  <animation>
   <frame tileid="1" duration="100"/>
   <frame tileid="3" duration="100"/>
   <frame tileid="4" duration="100"/>
   <frame tileid="5" duration="100"/>
  </animation>
 </tile>
</tileset>
