<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="doors" tilewidth="32" tileheight="32" tilecount="4" columns="2">
 <image source="doors.png" width="64" height="64"/>
</tileset>
