 		- - MR HORSEMAN Alpha-Version - -
GITHUB - - - https://github.com/JoseTurdeZarandieta/MrHorseMan

TEAM MEMBERS:
 - BIEL CADENAS BENEDICTO
 - DAVID GARCÍA CASTRO
 - JOSÉ TUR DE ZARANDIETA

Game Description: Mr Horseman is a game about the bizarre adventures of the Horse who developed a human side. 

How to play:

- A / D to move left/right
- Spacebar to jump
- F9 toggles collision view
- F10 toggles FPS cap
- F12 toggles Vsync

Implemented features in Alpha-version:

- Jump and Double-Jump
- Enemies and enemy damage
- Fall damage
- DeathZones
- Item collection